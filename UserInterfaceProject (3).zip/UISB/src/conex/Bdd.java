package conex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Bdd {

	public Connection con;
	Statement stmt;
	private String sql;
	private String url;
	private String username;
	private String password;
	
	public Bdd(String Url,String Username,String Password)
	{
		this.url = Url;
		this.username = Username;
		this.password = Password;
		
	}
	
	public Bdd()
	{
		
		
	}
	
	//connection base de donn�e
	public Connection connexionDataBase()
	{
		
		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
		return con;
	}
	
	//fermer connection 
	public void closeConnexion()
	{
		try {
			con.close();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
		con = null;
	}
	
	//methode pour requete executeQuery
	public ResultSet executeQuery(String sql)
	{
		connexionDataBase();
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
		return rs;
	}
	
	//methode requete update
	public String executeUpadte(String sql)
	{
		connexionDataBase();
		String result = "";
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			result = sql;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
		return result;
	}
	
	//afficher toute une table avec nom Table --> verif
	public ResultSet afficheTable(String nomTable) {
		connexionDataBase();
		String sql = "SELECT * FROM " + nomTable;
		System.out.println(sql);
		return this.executeQuery(sql);
	}
	
	// methode requette insert avec parametre nomTable et nomColonnes --> verifi�
	public String insertDonnee(String nomTable, List nomColonnes, List contenue) {
		connexionDataBase();
		sql = "INSERT INTO " + nomTable + " ( ";
		for(int i =0 ; i <= nomColonnes.size() - 1 ; i ++) {
			sql += nomColonnes.get(i);
				if(i < nomColonnes.size() - 1){
					sql += ", ";
				}
			}
		sql +=  ") VALUES ( ";
		for(int i = 0; i <= contenue.size() -1 ; i++) {
			sql += "'" + contenue.get(i) + "'"  ;
			if(i < contenue.size() - 1 ) {
				sql += ", ";
			}
		}
		sql += ")";
		System.out.println("insertDonn�e : " + sql);
		return this.executeUpadte(sql);
	}
	
	//afficher toutes la table avec parametre etat  --> verifi�
	public ResultSet afficheAvecPara(String nomTable,String condition) {
		connexionDataBase();
		sql = "SELECT * FROM " + nomTable + " Where " + condition;
		return this.executeQuery(sql); 
	}
	
	//requete count + condition 
	public ResultSet countPara(String nomTable,String condition) {
		connexionDataBase();
		sql = "SELECT COUNT(*) AS count FROM " + nomTable + " WHERE " + condition;
		return this.executeQuery(sql);
	}
	
	//affiche elements d'une colonne avec parametre etat --> verifi�
	public ResultSet afficheColonPara(String nomTable, List nomColonne,String condition) {
		connexionDataBase();
		sql = "SELECT ";
		for(int i = 0; i<= nomColonne.size() -1;i++) {
			sql += nomColonne.get(i);
			if(i<nomColonne.size()-1) {
				sql += ",";
			}
		}
		sql += " FROM " + nomTable + " WHERE " + condition;
		System.out.println("afficheColonPara : " + sql);
		return this.executeQuery(sql);
	}

	//modifier un champ d'une table avec nomTable, nomColonne, contenue,condition --> verifi�
	public String modifChampCondi(String nomTable,List nomColonne,List contenu,String condition) {
		connexionDataBase();
		sql = "UPDATE " + nomTable + " SET ";
		for(int i = 0; i <= nomColonne.size()-1; i++) {
			sql += nomColonne.get(i) + "='" + contenu.get(i) + "'";
			if(i<nomColonne.size() - 1) {
				sql += ",";
			}
		}
		sql += " WHERE " + condition;
		System.out.println("modifie champ : " + sql);
		return this.executeUpadte(sql);
	}
	
	//supprimer avec parametre --> verifi�
	public String suppAvecPara(String nomTable, String condition) {
		connexionDataBase();
		sql = "DELETE FROM " + nomTable + " WHERE " + condition;
		System.out.println("suppAvecPara : " + sql);
		return this.executeUpadte(sql);
		
	}
	
	//methode dernier champ ajout� a la base 
    public ResultSet max() {
        connexionDataBase();

        String sql = "select MAX(IdImage) AS 'max' FROM images";
        System.out.println(sql);

        return this.executeQuery(sql);
    }
    
   
}
