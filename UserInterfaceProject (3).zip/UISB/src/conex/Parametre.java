package conex;

public class Parametre {

	public String url = "jdbc:mysql://localhost:3306/projet?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC";
	public String username = "root";
	public String password = "";
	
	
	
	
}
