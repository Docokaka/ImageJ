package conex;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;

import programme.Campagne;
import programme.Essaie;
import programme.Image;
import programme.TripletPosition;
import programme.User;

public class TestRequete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	Essaie a = new Essaie();
	
	Campagne b =new Campagne("");
	
	b.getNbImagesCampagne(1);
	}

}
