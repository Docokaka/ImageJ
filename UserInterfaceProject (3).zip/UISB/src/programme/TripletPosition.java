package programme;

public class TripletPosition<x,y,z> {

	private double x;
	private double y;
	private double n;
	
	public TripletPosition(double X,double Y,double N)
	{
		this.x = X;
		this.y = Y;
		this.n = N;
	}

	public double getX() {
		return this.x;
	}

	public double getY() {
		return this.y;
	}

	public double getN() {
		return this.n;
	}

	@Override
	public String toString() {
		return "TripletPosition [x=" + this.x + ", y=" + this.y + ", n=" + this.n + "]";
	}
	
	
	
	
}
