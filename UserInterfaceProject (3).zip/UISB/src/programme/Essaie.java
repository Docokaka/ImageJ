package programme;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import conex.Bdd;
import conex.Parametre;



public class Essaie {
	
	public static ArrayList<Essaie> listEssaie = new ArrayList<>();
	
	private int idEssaie;
	private ArrayList<Image> listImages;
	private String description;
	private String dateEssaie;
	private int nombresImagesEssaie;
	private int nombresCellulesEssaie;
	private Double moyenneCellulesEssaie;
	private int idUtilisateur; // voir incrementation avec idUtilisateur session en cours 
	private int idCampagne; 
	ResultSet rs;
	
	//constructeur avec description | gerer les autres constructeurs
	
	//voir instanciation idEssaie
	public Essaie(String Description)
	{
		this.description = Description;
		 
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		this.dateEssaie = s.format(date);		
	}
	
	//constrcuteur pour import listImage mais pas sur utile?
	public Essaie (String description, ArrayList<Image> ListImages)
	{
		this.description = description;
		this.listImages = ListImages;
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		this.dateEssaie = s.format(date);
		
		 // requete upadate cr�ation d'un essaie avec description, un groupe d'image a analyser et heure/date
		 	//voir listImage avec id ?...
		//
	}
	
	//constructeur renitialisation listEssaie
	public Essaie(int idEssaie,String date,String description,int nbrImag,int nbrCellules,Double moyCelEssaie, int idUtilisateur, int idCampagne)
	{
		this.idEssaie = idEssaie;
		this.dateEssaie = date;
		this.description = description;
		this.setNombresImagesEssaie(nbrImag);
		this.setNombresCellulesEssaie(nbrCellules);
		this.setMoyenneCellulesEssaie(moyCelEssaie);
		this.idUtilisateur = idUtilisateur;
		this.setIdCampagne(idCampagne);
		//this.listImages = new ArrayList<>();
	}
	//requete pour methode non static
	public Essaie()
	{
		
	}
	
	public int getidCampagne() {
		return this.idCampagne;
	}
	
	public void setidCampagne(int idCamp) {
		this.idCampagne=idCamp;
	}
	
	//getter/setter
	public String getDescription() {
		return this.description;
	}

	public String getDateEssaie() {
		return this.dateEssaie;
	}

	public int getIdUtilisateur() {
		return this.idUtilisateur;
	}
	
	public ArrayList<Image> getListImages() {
		return this.listImages;
	}

	//renvoi la description de l'idEssaie en parametre --> verifi� 
	public String getDescription(int idEssaie) {
		
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		List<String> nomColonne = Arrays.asList("description");
		String resultat = null;
		
		try {
			
			rs = db.afficheColonPara("essaie", nomColonne , "idEssaie = " + idEssaie );
			while(rs.next())
			{
			resultat = rs.getString("description");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
			resultat = null;
			
		}
		
		finally {
			db.closeConnexion();
		}
		
		return resultat;
		
	}

	
	


	//modifie description d'un essaie pass� en parametre avec description en para --> verifi�
	public void setDescription(int idEssaie, String Description) {
		
		/*
		 * requette update pour modifier description d'un essaie (this.id)
		 */
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		List<String> listColonne = Arrays.asList("description");
		List contenu = Arrays.asList(Description);
		db.modifChampCondi("essaie", listColonne, contenu, "idEssaie = " + idEssaie);
		
		db.closeConnexion();
		
		
	}

	
	//comprend pas ? 
	public int getIdEssaie() {
		return idEssaie;
	}

	//renvoie date de cr�ation de l'esssaie --> verifi�
		public String getDateEssaie(int idEssaie) {
		

			Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
			
			List<String> nomColonne = Arrays.asList("date");
			String resultat = null;
			
			try {
				
				rs = db.afficheColonPara("essaie", nomColonne , "idEssaie = " + idEssaie );
				while(rs.next())
				{
				resultat = rs.getString("date");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				e.getMessage();
				resultat = null;
				
			}
			
			finally {
				db.closeConnexion();
			}
			
			return resultat;
			
		}

		//methodes
	
		//met a jour listEssaie --> verifi�
		public void renitialiseListEssaie()
		{
			listEssaie.clear();
			
			Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
			
			
			try {
				rs = db.afficheTable("essaie");
				while(rs.next())
				{
					listEssaie.add(new Essaie(rs.getInt("idEssaie"), rs.getString("date"), rs.getString("description"), rs.getInt("nbrImg"), rs.getInt("nbrCellule"), rs.getDouble("moyCelEssaie"),rs.getInt("idUtilisateur"),rs.getInt("idCampagne")));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				e.getMessage();
			}
			finally {
				db.closeConnexion();
			}
			
		}
		
		//affiche listImage de l'essaie --> a verifier 
		public void afficheListImage(int idEssaie)
		{
			renitialiseListEssaie();
			for(int i = 0; i< listEssaie.size();i++)
			{
				if(listEssaie.get(i).getIdEssaie() == idEssaie)
				{
					if(listEssaie.get(i).getListImages().isEmpty() == true)
					{
						System.out.println("vide");
					}
					else
					{
						for(int c = 0; c < listEssaie.get(i).getListImages().size();c++)
						{
							System.out.println("idImage : " + listEssaie.get(i).getListImages().get(c) + " | " + "date : " + listEssaie.get(i).getListImages().get(c) );
						}
					}
				}
				else
				{
					System.out.println("pas trouv�");
				}
				
			}
		}
		
		//affiche listeEssaie --> verifi� 
		public static void afficheListEssaie()
		{
			listEssaie.clear();
			Essaie a = new Essaie();
			a.renitialiseListEssaie();
			
			if(listEssaie.isEmpty() == true)
			{
				System.out.println("vide");
			}
			else
			{
				for(int i =0; i < listEssaie.size();i++)
				{
					System.out.println( "idEssaie : " + listEssaie.get(i).getIdEssaie() + " | " + "date : " + listEssaie.get(i).getDateEssaie() +
										" | " + "idUtilisateur : " + listEssaie.get(i).getIdUtilisateur() + " | " + "idUtilisateur : " +
										listEssaie.get(i).getIdUtilisateur());
				}
			}
		}
		
		// cr�e un essaie --> voir avec groupe pour conditino cr�ation essaie
		public void cr�eEssaie(String description)
		{
			
			Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
			List<String> listColonne = Arrays.asList("date","description","idUtilisateur");
		
			List contenuTableau = Arrays.asList(new Essaie(description).getDateEssaie(),description,this.idUtilisateur); //gerer idUtilisateur avec cession et description 
			 
			//.db.insertDonnee("essaie", listColonne, contenuTableau);
			db.closeConnexion();
		}
		
		
		//ajout une image a l'essaie | place idEssaie dans table image --> requette bonne partie java non 
		public void ajoutImage(int idEssaie,int idImage )  
		{
			
			Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
			List<String> listColonne = Arrays.asList("idEssaie");
			List contenu = Arrays.asList(idEssaie);
			
			db.modifChampCondi("images", listColonne, contenu, "idImage = " + idImage);
			db.closeConnexion();
			
			for(int i =0;i<listEssaie.size();i++)
			{
				if(listEssaie.get(i).getIdEssaie() == idEssaie )
				{
					Image a = new Image("");
					a.renitialListImage();
					for(int c = 0 ; c < Image.getListImages().size(); c++ )
					{
						if(Image.getListImages().get(c).getIdImage() == idImage)
						{
							listEssaie.get(i).getListImages().add(Image.getListImages().get(c));
						}
					}
				}
			}
	}

	
	//methode supp une image d'un essaie -->  verfi� +  voir renitialise list images de l'essaie
	public void removeImageEssaie(int idImage)
	{
		
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		List<String> listColonne = Arrays.asList("idEssaie");
		List contenu = Arrays.asList(0);
		db.modifChampCondi("images", listColonne, contenu, "idImage = " + idImage);
		
		
		db.closeConnexion();
		
	
		for(int i = 0; i< listEssaie.size();i++)
		{
			for(int c = 0; c< listEssaie.get(i).getListImages().size();c++)
			{
				if(listEssaie.get(i).getListImages().get(c).getIdImage() == idImage )
				{
					listEssaie.get(i).getListImages().remove(c);
				}
			}
			
		}
	
		
	}

	
	// renvoie stat du nombre d'images de l'essaie --> verifi� | voir pour ajouter a base de donn�e 
	public int getNbImagesEssaie(int idEssaie) {
		
		int resultat = 0;
		
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		rs = db.countPara("images", "idEssaie = " + idEssaie);
		
		try {
			while(rs.next())
			{
				resultat = rs.getInt("count");
			}	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
		finally {
			db.closeConnexion();
		}
		
		setNbrImagesEssaie(idEssaie, resultat);
		
		return resultat;
	}

	public void setNbrImagesEssaie(int idEssaie,int resultat)
	{
		Bdd dl = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("nbrImg");
		List contenu = Arrays.asList(resultat);
		dl.modifChampCondi("essaie", listColonne, contenu, "idEssaie = " + idEssaie);
		dl.closeConnexion();
	}

	// renvoie le nombre total de cellule de l'essaie --> verifi� mais mieux verifi� si possible
	public int getNbCellulesEssaie(int idEssaie) {
		{
			ArrayList<Integer> listId = new ArrayList<>();
			int resultat = 0;
			Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
			rs = db.afficheAvecPara("images", "idEssaie = " + idEssaie);
			try {
				while(rs.next())
				{
					listId.add(rs.getInt("idImage"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				db.closeConnexion();
			}
			
			
			
			if(listId.isEmpty() == true)
			{
				return 0;
			}
			else
			{
				for(int i = 0; i<listId.size();i++)
				{
					Image a = new Image("");
					resultat += a.getNbrCellulesImage(listId.get(i));
				}
				
			}
			setNbrCellulesEssaie(idEssaie, resultat);
			return resultat;			
		}
	}
	
	public void setNbrCellulesEssaie(int idEssaie,int resultat)
	{
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("nbrCellule");
		List contenu = Arrays.asList(resultat);
		db.modifChampCondi("essaie", listColonne, contenu, "idEssaie = " + idEssaie);
		db.closeConnexion();
	}

	
	
	//renvoie la moyenne de nombre de  cellule par image de  l'essaie --> verifi�
	public double getMoyNbCellules(int idEssaie) {
		
		double resultat = 0.0;
		
		resultat = (double) getNbCellulesEssaie(idEssaie)/getNbImagesEssaie(idEssaie);
		
		setMoyNbCellulesEssaie(idEssaie, resultat);
		return resultat;
	}
	
	public void setMoyNbCellulesEssaie(int idEssaie,Double resultat)
	{
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("moyCelEssaie");
		List contenu = Arrays.asList(resultat);
		db.modifChampCondi("essaie", listColonne, contenu, "idEssaie = " + idEssaie);
		db.closeConnexion();
	}
	//revoir interface admin avec equipe --> verifi� 
	
	public void ModifyDescriptionEssaie(int idEssaie,String description)  
	{
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		List<String> listColonne = Arrays.asList("description");
		List contenu = Arrays.asList(description);
		db.modifChampCondi("essaie", listColonne, contenu, "idEssaie = " + idEssaie);
		db.closeConnexion();
		
	}
	public int getNombresImagesEssaie() {
		return nombresImagesEssaie;
	}
	public void setNombresImagesEssaie(int nombresImagesEssaie) {
		this.nombresImagesEssaie = nombresImagesEssaie;
	}
	public int getNombresCellulesEssaie() {
		return nombresCellulesEssaie;
	}
	public void setNombresCellulesEssaie(int nombresCellulesEssaie) {
		this.nombresCellulesEssaie = nombresCellulesEssaie;
	}
	public Double getMoyenneCellulesEssaie() {
		return moyenneCellulesEssaie;
	}
	public void setMoyenneCellulesEssaie(Double moyenneCellulesEssaie) {
		this.moyenneCellulesEssaie = moyenneCellulesEssaie;
	}
	public int getIdCampagne() {
		return idCampagne;
	}
	public void setIdCampagne(int idCampagne) {
		this.idCampagne = idCampagne;
	}
	
	
	
	
	
}


