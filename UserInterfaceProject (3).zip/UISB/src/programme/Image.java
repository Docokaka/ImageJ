package programme;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import programme.TripletPosition;
import conex.Parametre;
import conex.Bdd;


public class Image  {
	
	public static ArrayList<Image> listImages = new ArrayList<Image>();
	private int idImage;
	private String dateImage;
	private String url;
	private ArrayList<TripletPosition<Double,Double,Double>> listAmas;
	private int idUtilisateur; // instancier avec idUser de cession 
	private int idEssaie; //voir quand l'instancier
	
	ResultSet rs;
	
	
	//gerer creation essaie avec import images 
	//constructeur
	// voir pour instancier idImage
	public Image()
	{
		
		listAmas = new ArrayList<>();
		//instancier idUser ici !!
		//instancier url
		
		
		
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		this.dateImage = s.format(date);
		
		renitialListImage();
		
	}
	
	//constructeur pour methode non static 
	public Image(String d)
	{
		
		
	}
	
	//constructeur pour mise a jour lisImages
	public Image(int idImage,String date,int idUtilisateur,int idEssaie,String Url)
	{
		this.idImage = idImage;
		this.dateImage = date;
		this.idUtilisateur = idUtilisateur;
		this.idEssaie = idEssaie;
		this.url = Url;
		this.listAmas = new ArrayList<>();
	}
	
	
	//getter et setter
	
	//?
	
	public int getIdImage() {
		// renvoi requete sql 
		return this.idImage;
	}
	
	public String getDateImage() {
		return this.dateImage;
	}

	public int getIdUtilisateur() {
		return this.idUtilisateur;
	}

	public int getIdEssaie() {
		return this.idEssaie;
	}

	public String getUrl() {
		return this.url;
	}
	
	public void setUrl(String url) {
		this.url=url;
	}

	public ArrayList<TripletPosition<Double, Double, Double>> getListAmas() {
		return this.listAmas;
	}

	public static ArrayList<Image> getListImages() {
		Image a = new Image();
		a.renitialListImage();
		return listImages;
	}

	//renvoie idUtilisateur de user qui a importe l'image --> verifi�
	public int getIdUtilisateur(int idImage) {
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> nomColonne = Arrays.asList("idUtilisateur");
		Integer resultat = null;
		try {
			rs = db.afficheColonPara("images",nomColonne , "idImage = " + idImage);
			while(rs.next())
			{
			resultat = rs.getInt("idUtilisateur");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();		
		}
		finally {
			db.closeConnexion();
		}
		return resultat;
	}

	//methodes 

	//renvoie date de l'import de l'image --> verifi�
	public String getDateImage(int idImage) {
		/*
		 * requete executeQuery renvoie date importation image 
		 */
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> nomColonne = Arrays.asList("date");
		String resultat = null;
		try {	
			rs = db.afficheColonPara("images", nomColonne , "idImage = " + idImage );
			while(rs.next())
			{
			resultat = rs.getString("date");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
			resultat = null;
		}
		finally {
			db.closeConnexion();
		}
		return resultat;
	}
	
	//import d'une image --> fonctionne mais voir avec groupe pour condition des imports d'images
	public void importImage(String url) {
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("date","idUtilisateur","idEssaie", "url");
		List contenuTableau = Arrays.asList(new Image().getDateImage(),this.idUtilisateur,this.idEssaie, url); // voir poir idUtilisateur et essaie
		db.insertDonnee("images", listColonne, contenuTableau);
		db.closeConnexion();
		renitialListImage();
	}
	
	public void renitialListImage() {
		listImages.clear();
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);		
		try {
			rs = db.afficheTable("images");
			while(rs.next())
			{
				listImages.add(new Image(rs.getInt("idImage"),rs.getString("date"), rs.getInt("idUtilisateur"), rs.getInt("idEssaie"), rs.getString("url")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
		finally {
			db.closeConnexion();
		}		
	}
	
	//import liste d'image --> voir pour import 
	public void importListImage(List<String> listImage)
	{
		
		
	}
	

	/*ajouter des amas a une image avec para :
	  idImage, abcsisse de l'amat,ordonnee de l'amat 
	  et nombre de cellules de l'amat --> requette verifie 
	*/
	
	public void AjoutAmas(int idImage,Double X,Double Y,Double N) {
		
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("x","y","n","idImage");
		List contenu = Arrays.asList(X,Y,N,idImage);
		
		db.insertDonnee("amas", listColonne	, contenu);
		
		db.closeConnexion();
		
		renitialListImage();
		
		for(int i =0; i< listImages.size();i++)
		{
			if(listImages.get(i).getIdImage() == idImage)
			{
				
				
				listImages.get(i).getListAmas().add(new TripletPosition<>(X, Y, N));
				
				//foonctionne ici mais pas dans la methode getListAma
				/*
				for(int c = 0; c < listImages.get(i).getListAmats().size();c++)
				{
					System.out.println("amat numero : " + (c+1) + " | " + "x = " + listImages.get(i).getListAmats().get(c).getX() + 
							" | " + " y " + listImages.get(i).getListAmats().get(c).getY() + " | " + "nombre de cellules z : " +
							listImages.get(i).getListAmats().get(c).getZ());
				}
				*/	
			}
		}
	}

	//renvoie le nombre de cellule d'une image --> verifi�
	public int getNbrCellulesImage(int idImage) {
		int resultat = 0;
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("n");
		rs = db.afficheColonPara("amas", listColonne, "idImage = " + idImage);
		try {
			while(rs.next())
			{
				resultat += rs.getInt("n");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
		finally {
			db.closeConnexion();
		}
		return resultat ;
	}

	//renvoi listImages --> verifi�
	public static void toStringList() {
		listImages.clear();
		Image a = new Image("");
		a.renitialListImage();
		if(listImages.isEmpty() == true) {
			System.out.println("vide");
		}
		else {
			for(int i =0; i < listImages.size();i++) {
				System.out.println( "idImage : " + listImages.get(i).getIdImage() + " | " + "date : " + listImages.get(i).getDateImage() +
									" | " + "idUtilisateur : " + listImages.get(i).getIdUtilisateur() + " | " + "idEssaie : " +
									listImages.get(i).getIdEssaie() + " | " + "url : "+listImages.get(i).getUrl());
			}
		}
	}

	//renvoie la position et le nombre de cellule de tous les amats --> chaue ajout d'un amat supprime precedent probleme
	public void getListAmat(int idImage) {
		for( int i = 0; i< listImages.size();i++) {
				if(listImages.get(i).getIdImage() == idImage) {
					if(listImages.get(i).getListAmas().isEmpty() == true) {
						System.out.println("vide");
						break;
					}
					else {
						for(int c = 0; c < listImages.get(i).getListAmas().size();c++) {
							System.out.println(listImages.get(i).getListAmas().size());
							System.out.println("amas numero : "+(c+1)+" | "+"x = "+listImages.get(i).getListAmas().get(c).getX()+" | "+" y "+listImages.get(i).getListAmas().get(c).getY()+" | "+"nombre de cellules z : "+listImages.get(i).getListAmas().get(c).getN());
						}
				}
			}	
		}	
	}
	
	//renvoie le max d'un champ
    public int getMaxIdImage() {
        Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
        int resultat =0;
        rs = db.max();
        try {
            while(rs.next())
            {
                resultat = rs.getInt("max");
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
            db.closeConnexion();
        }

        if(resultat == 0)
        {
            System.err.println("erreur pas d'images trouv�");
        }
        return resultat;
    }
}
	
	
	
	
		

	

