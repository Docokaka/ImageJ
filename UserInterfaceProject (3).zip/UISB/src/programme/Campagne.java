package programme;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import conex.Bdd;
import conex.Parametre;

public class Campagne {

	
	
	
	public static ArrayList<Campagne> listCampagne = new ArrayList<>();
	
	private int idCampagne;  
	private String dateCampagne;
	private ArrayList<Essaie> listEssaies;
	private int idUtilisateur;
	private int nbrEssaie;
	private double moyNbrEssaie;
	private int nbrCelCampagne;
	private int nbrImagesCamp;
	
	ResultSet rs;
	
	//constructeur normal
	public Campagne() {
		this.listEssaies = new ArrayList<Essaie>();
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		this.dateCampagne = s.format(date);
	}
	
	//constrcuteur pour import listEssaie --> voir avec groupe
	public Campagne( ArrayList<Essaie> ListEssaies) {	
		this.listEssaies = ListEssaies;
		
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		this.dateCampagne = s.format(date);
	}
	
	//constructeur pour renitialise list
	public Campagne(int idCampagne,String date,int nbrEssaie,Double moyNbrEssaie,int nbrCelCampagne,int nbrImagesCamp,int IdUtilisateur)
	{
		this.idCampagne = idCampagne;
		this.dateCampagne = date;
		this.nbrEssaie = nbrEssaie;
		this.moyNbrEssaie = moyNbrEssaie;
		this.nbrCelCampagne = nbrCelCampagne;
		this.nbrImagesCamp = nbrImagesCamp;
		this.idUtilisateur = IdUtilisateur;
		
	}
	
	//constructeur methode non static 
	public Campagne(String nonStatic)
	{
		
	}
	
	//getter/setter
	


	public ArrayList<Essaie> getListEssaies() {
		return listEssaies;
	}


	public int getIdCampagne() {
		return idCampagne;
	}
	
	public String getDate() {
		// TODO Auto-generated method stub
		return this.dateCampagne;
	}
	
	
	public String getDateCampagne() {
		return dateCampagne;
	}

	public int getIdUtilisateur() {
		return idUtilisateur;
	}

	public int getNbrEssaie() {
		return nbrEssaie;
	}
	
	public void setNbrEssaie(int nbessay) {
		 this.nbrEssaie=nbessay;
	}

	public double getMoyNbrEssaie() {
		return moyNbrEssaie;
	}

	public int getNbrCelCampagne() {
		return nbrCelCampagne;
	}

	public int getNbrImagesCamp() {
		return nbrImagesCamp;
	}

	//renvoie la liste des campagne mit a jour --> a verifier 
	public static ArrayList<Campagne> getListCampagne() {
		Campagne a =new Campagne("");
		a.renitialiseListCampagne();
		return listCampagne;
	}

	//cr�e une campagne --> verifi�
	public void creeCampagne()
	{
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("date","idUtilisateur");
		List contenu = Arrays.asList(new Campagne().getDate(),this.idUtilisateur); // voir pour idUtilisateur
		
		db.insertDonnee("campagne", listColonne, contenu);
		db.closeConnexion();
	}
	
	
	
	//met a jour la listCampagne --> a verifier 
	public void renitialiseListCampagne()
	{
		listCampagne.clear();
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		rs = db.afficheTable("campagne");
		try {
			while(rs.next())
			{
				listCampagne.add(new Campagne(rs.getInt("idCampagne"), rs.getString("date"), rs.getInt("nbrEssaie"), rs.getDouble("moyNbrCelEssaie"), rs.getInt("nbrCelCampagne"), rs.getInt("nbrImagesCamp"),rs.getInt("idUtilisateur")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
		finally {
			db.closeConnexion();
		}
	
	}
	
	// ajout un essaie � la campagne --> verifi� | voir pour add listEssaie java 
		public void addEssaie(int idCampagne,int idEssaie) 
		{
			Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
			List<String> listColonne = Arrays.asList("idCampagne");
			List contenu = Arrays.asList(idCampagne);
			
			db.modifChampCondi("essaie", listColonne, contenu, "idEssaie = " + idEssaie);
			db.closeConnexion();
		}
	
	//methode supp un essaie d'une campagne  voir avec equipe --> verifi�| voir pour sup dans listEssaie java
	public void removeEssaie(int idEssaie)
	{
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		List<String> listColonne = Arrays.asList("idCampagne");
		List contenu = Arrays.asList(0);
		
		db.modifChampCondi("essaie", listColonne, contenu, "idEssaie = " + idEssaie);
		db.closeConnexion();
		
	}
	
	
	
	//renvoie le nombre d'essaie de la campagne --> a verifier 
	public int getNbEssaieCampagne(int idCampagne)
	{
		int resultat = 0;
		
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		rs = db.countPara("essaie", "idCampagne = " + idCampagne);
		try {
			while(rs.next())
			{
				resultat = rs.getInt("count");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
		finally {
			db.closeConnexion();
		}
		setNbrEssaieCampagne(idCampagne, resultat);
		return resultat;
	}
	public void setNbrEssaieCampagne(int idCampagne,int resultat)
	{
		Bdd dl = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("nbrEssaie");
		List contenu = Arrays.asList(resultat);
		dl.modifChampCondi("campagne", listColonne, contenu, "idCampagne = " + idCampagne);
		dl.closeConnexion();
	}
	
	
	
	//nombre cellules de la campagne --> a verifier 
		public int getNmCellulesCampagne(int idCampagne)
		{
			int resultat = 0;
			
			
			Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
			
			rs = db.afficheAvecPara("essaie", "idCampagne = " + idCampagne);
			try {
				while(rs.next())
				{
					resultat += rs.getInt("nbrCellule");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				e.getMessage();
			}
			finally {
				db.closeConnexion();
			}
			
			setNbrCellulesCampagne(idCampagne, resultat);
			return resultat;
		}
		
		public void setNbrCellulesCampagne(int idCampagne,int resultat)
		{
			Bdd dl = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
			List<String> listColonne = Arrays.asList("nbrCelCampagne");
			List contenu = Arrays.asList(resultat);
			dl.modifChampCondi("campagne", listColonne, contenu, "idCampagne = " + idCampagne);
			dl.closeConnexion();
		}
	
	
	//moyenne du nombre de cellules par essaie de la campagne --> a verifier 
	public Double getMoyCellulesEssaie(int idCampagne)
	{
		Double resultat = 0.0;
		
		resultat = (double) getNmCellulesCampagne(idCampagne)/ getNbEssaieCampagne(idCampagne);
	
		setMoyCellulesEssaie(idCampagne, resultat);
		return resultat;
	}
	
	public void setMoyCellulesEssaie(int idCampagne,Double resultat)
	{
		Bdd dl = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("moyNbrCelEssaie");
		List contenu = Arrays.asList(resultat);
		dl.modifChampCondi("campagne", listColonne, contenu, "idCampagne = " + idCampagne);
		dl.closeConnexion();
	}
	
	
	
	
	//renvoie le nombre total d'image de la campagne --> a verifier
	public int getNbImagesCampagne(int idCampagne)
	{
		int resultat = 0;
		
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		List<String>  listColonne = Arrays.asList("nbrImg");
		rs = db.afficheColonPara("essaie", listColonne, "idCampagne = " + idCampagne);
		try {
			while(rs.next())
			{
				resultat += rs.getInt("nbrImg");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
		}
		finally {
			db.closeConnexion();
		}
		
		setNbrImagesCampagne(idCampagne, resultat);
		return resultat;
	}
	
	public void setNbrImagesCampagne(int idCampagne,int resultat)
	{
		Bdd dl = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("nbrImagesCamp");
		List contenu = Arrays.asList(resultat);
		dl.modifChampCondi("campagne", listColonne, contenu, "idCampagne = " + idCampagne);
		dl.closeConnexion();
	}
	
	
	
}
