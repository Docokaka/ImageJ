package programme;

public class Resultats {
	
	private int idImage;
	private int idEssai;
	private int idCampagne;
	private double moyenneCellulesImage;
	private int nombreImagesEssai;
	private double moyenneCellulesEssai;
	private int nombreEssaisCampagne;
	
	public Resultats(int idImg, int idEss, int idCamp, double moyCellImg, int nbImgEss, double moyCellEss, int nbEssCamp) {
		this.idImage=idImg;
		this.idEssai=idEss;
		this.idCampagne=idCamp;
		this.moyenneCellulesImage=moyCellImg;
		this.nombreImagesEssai=nbImgEss;
	    this.moyenneCellulesEssai=moyCellEss;
		this.nombreEssaisCampagne=nbEssCamp;
	}

	public int getIdImage() {
		return idImage;
	}

	public void setIdImage(int idImage) {
		this.idImage = idImage;
	}

	public int getIdEssai() {
		return idEssai;
	}

	public void setIdEssai(int idEssai) {
		this.idEssai = idEssai;
	}

	public int getIdCampagne() {
		return idCampagne;
	}

	public void setIdCampagne(int idCampagne) {
		this.idCampagne = idCampagne;
	}

	public double getMoyenneCellulesImage() {
		return moyenneCellulesImage;
	}

	public void setMoyenneCellulesImage(double moyenneCellulesImage) {
		this.moyenneCellulesImage = moyenneCellulesImage;
	}

	public int getNombreImagesEssai() {
		return nombreImagesEssai;
	}

	public void setNombreImagesEssai(int nombreImagesEssai) {
		this.nombreImagesEssai = nombreImagesEssai;
	}

	public double getMoyenneCellulesEssai() {
		return moyenneCellulesEssai;
	}

	public void setMoyenneCellulesEssai(double moyenneCellulesEssai) {
		this.moyenneCellulesEssai = moyenneCellulesEssai;
	}

	public int getNombreEssaisCampagne() {
		return nombreEssaisCampagne;
	}

	public void setNombreEssaisCampagne(int nombreEssaisCampagne) {
		this.nombreEssaisCampagne = nombreEssaisCampagne;
	}
	
}
