package programme;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import conex.Bdd;
import conex.Parametre;

/**
 * 
 * ALTER TABLE essaie AUTO_INCREMENT=0 
 *
 */



public class User {

	
	private int idUser;
	private String login;
	private String password;
	private String statut;
	private String url;
	
	private ResultSet rs;
	
	private ArrayList<User> listUser = new ArrayList<User>();
	
	
	/*//gerer doublon user | garder variable static statut pour admin ? 
	public User(String Password,String Pseudo,String Statut)
	{
		this.pseudo = Pseudo;
		this.password = Password;
		this.statut = Statut;
		
	}
	

	//constrcuteur pour methode renitialise listUser
	public User(int idUser,String pseudo,String password,String statut)
	{
	
		this.idUser = idUser;
		this.pseudo = pseudo;
		this.password = password;
		this.statut = statut;
	}*/
	
	public User(int idUser,String log, String pass, String stat)
	{
		this.idUser=idUser;
		this.login=log;
		this.password=pass;
		this.statut=stat;
	}	
	
	public int getIdUser() {
		return this.idUser;
	}
	
	public String getLogin() {
		return this.login;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	public String getStatut() {
		return this.statut;
	}

	// renvoi le login de idUser donn�e en parametre --> verrifi�
	public String renvoiPseudo(int idUser) {
		
		
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		
		List<String> nomColonne = Arrays.asList("pseudo");
		String resultat = null;
		
		try {
			rs = db.afficheColonPara("utilisateurs",nomColonne , "idUtilisateur = " + idUser);
			while(rs.next())
			{
			resultat = rs.getString("pseudo");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
			resultat = null;
		}
		finally {
			db.closeConnexion();
		}
		return resultat;
	}
	
	//renvoie password de idUser pass� en parametre --> verifi�
	public String renvoiPassword(int idUser) {
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> nomColonne = Arrays.asList("password");
		String resultat = null;
		try {
			rs = db.afficheColonPara("utilisateurs",nomColonne , "idUtilisateur = " + idUser);
			while(rs.next())
			{
			resultat = rs.getString("password");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			e.getMessage();
			resultat = null;	
		}
		finally {
			db.closeConnexion();
		}
		return resultat;
	}

	
	//renvoie statut de l'idUser passe en paramtre --> verifi�
	public String renvoiStatut(int idUser) {
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> nomColonne = Arrays.asList("statut");
		String resultat = null;
		try {
			rs = db.afficheColonPara("utilisateurs",nomColonne , "idUtilisateur = " + idUser);
			while(rs.next()) {
			resultat = rs.getString("statut");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			e.getMessage();
			resultat = null;
		}
		finally {
			db.closeConnexion();
		}
		return resultat;
	}

	
	//mets a jour la listUser --> verifi�
	public void renitialiseListUser() {
		listUser.clear();
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		try {
			rs = db.afficheTable("utilisateurs");
			while(rs.next())
			{
				listUser.add(new User(rs.getInt("idUtilisateur"),rs.getString("pseudo"), rs.getString("password"), rs.getString("statut")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			db.closeConnexion();
		}
	}
	
	// pas verifi�
	public ArrayList<User> getListUser() {
		return listUser;
	}

	//methode a mettre sur interface 
	 public void table() {
	  	/*
		Bdd db_conect = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> listColonne = Arrays.asList("idUtilisateur","password", "pseudo","staut");
	  	rs = db_conect.afficheAvecPara("utilisateurs", listColonne);
	  	*/
	  }

	//ajout user --> verifi� | voir pour les doublons 
	public void CreatUser(String Pseudo,String Password,String statut) {
		Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
		List<String> nomColonne = Arrays.asList("pseudo","password","statut");	
		List contenuTableau = Arrays.asList(Pseudo,Password,statut);
		db.insertDonnee("utilisateurs", nomColonne, contenuTableau);
		this.renitialiseListUser();		
		db.closeConnexion();
	}
	
	//suprimer un user --> verifi�
	public void deleteUser(int idUser) throws Exception {
			Bdd db = new Bdd(new Parametre().url, new Parametre().username, new Parametre().password);
			db.suppAvecPara("utilisateurs", "idUtilisateur = " + idUser);
			db.closeConnexion();
			this.renitialiseListUser();
	}
	
	//renvoie list des user --> verifi�
	public void afficheListUser() {
		User a = new User(idUser, login, login, login);
		a.renitialiseListUser();
		
		if(listUser.isEmpty() == true)  {
			System.out.println("vide");
		}
		else {
			for(User b : getListUser()) {
				System.out.println( "idUtilisateur : " + b.getIdUser() + " | " +"pseudo : " + b.renvoiPseudo(b.getIdUser())+  "password : " +b.renvoiPassword(b.getIdUser()) + "|" +  "statut : " +b.renvoiStatut(b.getIdUser()) );
			}
		}
	}
	
}
