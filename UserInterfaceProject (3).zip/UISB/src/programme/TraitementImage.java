package programme;

import ij.measure.ResultsTable;
import ij.plugin.ImageCalculator;
import ij.process.ImageProcessor;

import java.io.File;
import java.sql.ResultSet;

import conex.Bdd;
import ij.IJ;
import ij.ImageJ;
import ij.ImagePlus;



public class TraitementImage extends ImageJ{

		String infile, outfile, format, name;

		public void processPicture(String infile, String outfile, String format, String name) {
			
			// autres param�tres
			int delta = 2; // taille de la croix

			// ouvre l'image � traiter
			IJ.open(infile);

			// renomme l'image d'entr�e pour normaliser l'�criture du script
			IJ.run("Duplicate...","title=originale");

			// ajuste la taille de l'image
			if (getWidth()>680) {
				IJ.run("Size...", "width=680 height=512"); 
			}

			// duplique l'image normalis�e en taille
			IJ.run("Duplicate...", "title=copie");

			// conserve la couche bleue
			IJ.selectWindow("copie");
			IJ.wait(300);
			IJ.run("RGB Stack");
			IJ.wait(100);
			IJ.run("Delete Slice");
			IJ.run("Delete Slice");

			// duplique l'image pour soustraire le fond
			IJ.run("Duplicate...", "title=background");

			// filtre median pour calculer le fond
			IJ.selectWindow("background");
			IJ.run("Median...", "radius=12");

			//On enregistre la copie, le background et l'original

			IJ.selectWindow("originale");
			IJ.save(outfile+"\\originale");
			ImagePlus originale= IJ.openImage(outfile+"\\originale.tif");

			IJ.selectWindow("copie");
			IJ.save(outfile+"\\copie");
			ImagePlus copie = IJ.openImage(outfile+"\\copie.tif");

			IJ.selectWindow("background");
			IJ.save(outfile+"\\background");
			ImagePlus background = IJ.openImage(outfile+"\\background.tif");

			// soustraction du fond
			ImageCalculator ic = new ImageCalculator();
			var Result = ic.run("Subtract",copie, background);
			IJ.selectWindow("background");
			IJ.run("Close");
			copie.show();
			IJ.selectWindow("copie");
			IJ.run("Close");

			// rehaussement du contraste et �limination de pts. aberrants
			IJ.selectWindow("copie.tif");
			IJ.run("Enhance Contrast", "saturated=4");


			// binarisation par isodata
			IJ.wait(100);
			IJ.run("Threshold", "IsoData");
			IJ.run("Threshold", "isoData");
			IJ.run("Threshold", "IsoData");
			IJ.run("Threshold", "IsoData apply");

			// post traitements : debruitage, ouverture, LPE
			IJ.run("Despeckle");
			IJ.run("Invert LUT");
			IJ.run("Watershed");
			IJ.run("Open");

			// comptage des particules
			IJ.run("Set Measurements...", "area centroid circularity redirect=None decimal=3");
			IJ.run("Analyze Particles...", "size=25-Infinity circularity=0.00-1.00 show=Masks display clear");
			ResultsTable RT1 = ResultsTable.getResultsTable();

			// incrustation des contours dans l'image
			IJ.selectWindow("copie.tif");
			IJ.run("Find Edges");
			IJ.run("RGB Color");
			IJ.run("Divide...", "value=255.000");

			IJ.selectWindow("copie.tif");
			IJ.save(outfile+"\\copie.tif");
			copie = IJ.openImage(outfile+"\\copie.tif");

			ic.run("Multiply", originale,copie);
			originale.show();

			IJ.run("Duplicate...","title=comptage");

			// ferme les fen�tres inutiles
			IJ.wait(100);
			IJ.selectWindow("Mask of copie.tif");
			IJ.run("Close");
			IJ.selectWindow("copie.tif");
			IJ.run("Close");
			IJ.selectWindow("originale");
			IJ.run("Close");
			IJ.selectWindow("originale.tif");
			IJ.run("Close");

			// recupere les infos sur les cellules
			int nResults = RT1.getCounter();
			double dataArea[] = new double [nResults]; // aire
			double dataXCen[] = new double [nResults]; // centre noyau X
			double dataYCen[] = new double [nResults]; // centre noyau Y
			double dataCirc[] = new double [nResults]; // circularite
			double dataNum[]  = new double [nResults]; // num cell dans zone

			for (int nrow=0; nrow<nResults; nrow++) {
				dataArea[nrow]=RT1.getValue("Area",nrow);
				dataXCen[nrow]=RT1.getValue("X",nrow);
				dataYCen[nrow]=RT1.getValue("Y",nrow);
				dataCirc[nrow]=RT1.getValue("Circ.",nrow);
			}

			// calcul des valeurs de r�f�rence

			// moyenne des aires et des circularit�s
			double meanArea = dataArea[0];
			double meanCirc = dataCirc[0];
			for (int nrow=1; nrow<nResults; nrow++) {
				meanArea = meanArea + dataArea[nrow];
				meanCirc = meanCirc + dataCirc[nrow];
			}
			meanArea = meanArea / nResults;
			meanCirc = meanCirc / nResults;

			// ecart-type des aires et des circularites
			double sigmaArea = 0;
			double sigmaCirc = 0;
			for (int nrow=0; nrow<nResults; nrow++) {
				sigmaArea = sigmaArea+((dataArea[nrow] - meanArea)*(dataArea[nrow] - meanArea));
				sigmaCirc = sigmaCirc+((dataCirc[nrow] - meanCirc)*(dataCirc[nrow] - meanCirc));
			}
			sigmaArea = Math.sqrt(sigmaArea / (nResults-1)) ;
			sigmaCirc = Math.sqrt(sigmaCirc / (nResults-1));

			// valeurs de r�f�rence pour les aires
			var minArea = (meanArea - 2* sigmaArea)*-1;
			var maxArea = meanArea + 2* sigmaArea;

			// correction de la taille moyenne apr�s eval des bornes
			double moyArea = 0;
			double numSample = 0;
			for (int nrow=0; nrow<nResults; nrow++) {
				if (dataArea[nrow]>=minArea && dataArea[nrow]<=maxArea) {
					moyArea = moyArea+dataArea[nrow];
					numSample ++;
				}
			}
			moyArea = moyArea/ numSample;

			// indice min de circularit�
			double minCirc = meanCirc - 2 * sigmaCirc;
			//minCirc = 0.6;

			// d�termination du nombre de cellules pour chaque zone
			// nombre total de cellules
			int numCell = 0;
			for (int nrow=0; nrow<nResults; nrow++) {
				double test=dataArea[nrow];
				double test2=dataCirc[nrow];
				// trop petite	
				if (dataArea[nrow]<minArea) dataNum[nrow] = 0;
				else
					// trop grande : estime le nombre de cellules
					if (dataArea[nrow]>maxArea) {
						dataNum[nrow] = Math.round(dataArea[nrow]/moyArea);
						numCell=numCell+(int)dataNum[nrow];		
					}
					else
						// bonne taille, pas assez circulaire
						if (dataCirc[nrow]<minCirc) dataNum[nrow] = 0;
						else {// tout va bien, 1 cellule
							dataNum[nrow] = 1;
							numCell++;// compte les cellules en plus
						}

			}

			// dessine sur l'image originale avec contours
			IJ.selectWindow("comptage");
			ImageProcessor ip = IJ.getProcessor();
			ip.setColor(0xff0000);
			double height = getHeight()-1;
			double width  = getWidth()-1;
			String nc="";		   
			for (int nrow=0; nrow<nResults; nrow++) {
				if (dataNum[nrow]>0) {
					double x1 = Math.round(Math.max(0,dataXCen[nrow]-delta)-1);
					double y1 = dataYCen[nrow]-13;
					double x2 = Math.min(width,dataXCen[nrow]+delta-1);
					double y2 = y1;
					double x3 = dataXCen[nrow]-1;
					double y3 = Math.max(0,dataYCen[nrow] - delta-13);
					double x4 = x3;
					double y4 = Math.min(height,dataYCen[nrow] + delta-13);
					// trace le centre de la zone
					ip.drawLine((int)x1,(int) y1,(int) x2,(int) y2);
					ip.drawLine((int)x3,(int) y3,(int) x4,(int) y4);
					// ecrit le nombre de cellules si > 1
					if (dataNum[nrow]>1) 
						nc=String.valueOf(nrow);
					ip.drawString(nc,(int)dataXCen[nrow]+delta,(int)dataYCen[nrow]-delta);
				}
			}

			// ecrit le r�sultat en bas de l'image
			/*IJ.selectWindow("comptage");
			   ip.setColor(0x000000);
			   IJ..run("Canvas Size...", "width=680 height=550 position=Top-Center");
			   ip.drawString("Nombre de cellules : "+nc,20,540);*/

			// enregistre la carte de comptage
			IJ.wait(50);
			File f = new File(outfile+"\\copie.tif");
			f.delete();
			f = new File(outfile+"\\originale.tif");
			f.delete();
			f = new File(outfile+"\\background.tif");
			f.delete();
			IJ.selectWindow("comptage");
			IJ.save(outfile+"\\"+name+"_comptage"+format);
			
			// ferme les images restantes
			IJ.wait(500);
			IJ.selectWindow("comptage");
			IJ.run("Close");
			IJ.selectWindow(name);
			IJ.run("Close");
			IJ.wait(50);
			IJ.selectWindow("Results");
			IJ.run("Close");
			Image img = new Image();
			int MaxImg = img.getMaxIdImage();
			for(int i=0; i<dataNum.length;i++) {
				img.AjoutAmas(MaxImg,dataXCen[i],dataYCen[i],dataNum[i]);
			}
			img.importImage(outfile+"\\"+name+"_comptage"+format);
		}
		
		

	}