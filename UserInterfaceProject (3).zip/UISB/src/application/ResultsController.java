package application;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import conex.Bdd;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import programme.Resultats;

public class ResultsController implements Initializable {

    @FXML
    private Button ShowResBtn;
    @FXML
    private Button ExportBtn;
    @FXML
    private Button BackBtn;
    @FXML
    private TableView<Resultats> ResultsTable;
    @FXML
    private TableColumn<Resultats, Integer> ImgIDResColumn;
    @FXML
    private TableColumn<Resultats, Integer> TryIdResColumn;
    @FXML
    private TableColumn<Resultats, Integer> CamIDResColumn;
    @FXML
    private TableColumn<Resultats, Double> AvgCpIResColumn;
    @FXML
    private TableColumn<Resultats, Integer> ImgpTryResColumn;
    @FXML
    private TableColumn<Resultats, Double> AvgCpTResColumn;
    @FXML
    private TableColumn<Resultats, Integer> TrypCResColumn;
    @FXML
	public ObservableList<Resultats> results = FXCollections.observableArrayList();
    @FXML
    private void backButtonPushed(ActionEvent event) throws IOException { 
    	        Parent manage = FXMLLoader.load(getClass().getResource("Main.fxml"));
    	        Scene scene = new Scene(manage);
    	        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	        primaryStage.hide();
    	        primaryStage.setScene(scene);
    	        primaryStage.setTitle("Main Menu");
    	        primaryStage.show();
       }
    @FXML
	private void AfficheResults(ActionEvent event) throws IOException {
        try {
        Bdd BDD = new Bdd("jdbc:mysql://localhost:3306/projet?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC", "root", "");
        BDD.connexionDataBase();
        String sql = "SELECT * FROM resultats";
        PreparedStatement stat =  BDD.con.prepareStatement(sql);
        ResultSet rs =  stat.executeQuery();
                    while (rs.next()) {
                    	results.add(new Resultats(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getDouble(4),rs.getInt(5),rs.getDouble(6),rs.getInt(7)));
                    }
                    BDD.con.close();
        } catch (Exception e) {
            // TODO: handle exception
        }
        ImgIDResColumn.setCellValueFactory(new PropertyValueFactory<Resultats , Integer>("idImage"));
        TryIdResColumn.setCellValueFactory(new PropertyValueFactory<Resultats , Integer>("idEssai"));
        CamIDResColumn.setCellValueFactory(new PropertyValueFactory<Resultats , Integer>("idCampagne"));
        AvgCpIResColumn.setCellValueFactory(new PropertyValueFactory<Resultats , Double>("moyenneCellulesImage"));
        ImgpTryResColumn.setCellValueFactory(new PropertyValueFactory<Resultats , Integer>("nombreImagesEssai"));
        AvgCpTResColumn.setCellValueFactory(new PropertyValueFactory<Resultats , Double>("moyenneCellulesEssai"));
        TrypCResColumn.setCellValueFactory(new PropertyValueFactory<Resultats , Integer>("nombreEssaisCampagne"));
        ResultsTable.setItems(results);
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}