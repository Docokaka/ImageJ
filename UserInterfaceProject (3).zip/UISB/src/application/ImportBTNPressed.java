package application;

import java.awt.FileDialog;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

import programme.TraitementImage;


public class ImportBTNPressed {
	 File[] nom;
	 public void Choiximg() {
		 
		//on instancie les variables
	        String inputdirectory, format;
	        String outputdirectory ="";

			//on choisi le ou les fichier(s )� importer
			JFrame Explo = new JFrame();
			FileDialog inputFiles = new FileDialog(Explo, "Choisissez un ou des fichier(s)", FileDialog.LOAD);
			inputFiles.setDirectory("C:\\");
			inputFiles.setFile("*.jpg");
			inputFiles.setMultipleMode(true);
			inputFiles.setVisible(true);
			inputdirectory = inputFiles.getDirectory();
			File[] filesdirectory = inputFiles.getFiles();
			String name[]=new String[filesdirectory.length];
			
			if(filesdirectory.length>1) {
				for(int i =0; i<filesdirectory.length;i++) {
					String directory = filesdirectory[i].toString();
					name[i]=directory.replace(inputdirectory+"\\", "").toLowerCase();
				}
			}else {
				String directory = filesdirectory[0].toString();
				String n = directory.replace(inputdirectory, "").toLowerCase();
				name[0]=directory.replace(inputdirectory, "").toLowerCase();
			}

			//on selectionne le repertoire de sortie
			JFileChooser outputFiles = new JFileChooser();
			outputFiles.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			int ret = outputFiles.showOpenDialog(null);
			if(ret == JFileChooser.APPROVE_OPTION) {
				outputdirectory = outputFiles.getSelectedFile().toString();
			}
			TraitementImage f = new TraitementImage();
			f.hide();
			//traite chaque fichier(jpg/png)
			for (int i=0; i<filesdirectory.length; i++) {
				inputdirectory = filesdirectory[i].toString().toLowerCase();
				//teste si le fichier a la bonne extension
				if(inputdirectory.endsWith(".jpg")) {
					f.processPicture(inputdirectory, outputdirectory, ".jpg", name[i]);
				}else if(inputdirectory.endsWith(".png")){
					f.processPicture(inputdirectory, outputdirectory, ".png", name[i]);
				}
			}
		}
	 
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
    }

}
