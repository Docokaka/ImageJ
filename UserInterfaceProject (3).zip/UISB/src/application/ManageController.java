package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import programme.Campagne;
import programme.Essaie;
import programme.Image;
import programme.User;
import conex.Bdd;

public class ManageController implements Initializable {
	@FXML
	private Tab usertab;
	@FXML
	private TableView<User> UserTable;
	@FXML
	private TableColumn<User, Integer> UIDColumn;
	@FXML
	private TableColumn<User, String> UserNameColumn;
	@FXML
	private TableColumn<User, String> PasswordColumn;
	@FXML
	private TableColumn<User, String> isAdminColumn;
	
	@FXML
	private Tab imgtab;
    @FXML
    private TableView<Image> ImageTable;
    @FXML
    private TableColumn<Image, Integer> ImageIDColumn;
    @FXML
    private TableColumn<Image, String> ImageDateColumn;
    @FXML
    private TableColumn<Image, Integer> ImageUserIDColumn;
    @FXML
    private TableColumn<Image, Integer> ImageTryIDColumn;
    @FXML
    private TableColumn<Image, String> ImageUrlColumn;

	@FXML
	private Tab trytab;
	@FXML
    private TableView<Essaie> TryTable;
    @FXML
    private TableColumn<Essaie, Integer> TryIDColumn;
    @FXML
    private TableColumn<Essaie, String> TryDateColumn;
    @FXML
    private TableColumn<Essaie, String> TryDescColumn;
    @FXML
    private TableColumn<Essaie, Integer> ImageAmountTryColumn;
    @FXML
    private TableColumn<Essaie, Integer> CellAmountTryColumn;
    @FXML
    private TableColumn<Essaie, Double> MoyCellTryColumn;
    @FXML
    private TableColumn<Essaie, Integer> UIDTryColumn;
    @FXML
    private TableColumn<Essaie, Integer> CampIdTryColumn;
    
	@FXML
	private Tab camtab;
	@FXML
    private TableView<Campagne> CampaignTable;
    @FXML
    private TableColumn<Campagne, Integer> CampaignIDColumn;
    @FXML
    private TableColumn<Campagne, String> CampaignDateColumn;
    @FXML
    private TableColumn<Campagne, Integer> TryAmountinCampaignColumn;
    @FXML
    private TableColumn<Campagne, Double> AvgCellsTryCamColumn;
    @FXML
    private TableColumn<Campagne, Integer> AmountCellsCamColumn;
    @FXML
    private TableColumn<Campagne, Integer> AmountImgCamColumn;
    @FXML
    private TableColumn<Campagne, Integer> UIDCamColumn;
      
	@FXML
	private TextField UnTF;
	@FXML
	private TextField PwTF;
	@FXML
	private TextField iATF;
	@FXML
    private Button backbtn;
	@FXML
	private Button srchbtn;
	@FXML
	private Button addbtn;
	@FXML
	private Button modbtn;
	@FXML
	private Button rembtn;
	@FXML
	public ObservableList<User> data = FXCollections.observableArrayList();
	@FXML
	public ObservableList<Image> img = FXCollections.observableArrayList();
	@FXML
	public ObservableList<Essaie> essaie = FXCollections.observableArrayList();
	@FXML
	public ObservableList<Campagne> campagne = FXCollections.observableArrayList();
	@FXML
    private void backButtonPushed(ActionEvent event) throws IOException { 
    	        Parent manage = FXMLLoader.load(getClass().getResource("Main.fxml"));
    	        Scene scene = new Scene(manage);
    	        Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	        primaryStage.hide();
    	        primaryStage.setScene(scene);
    	        primaryStage.setTitle("Main Menu");
    	        primaryStage.show();
       }
	@FXML void AfficheUsers(ActionEvent event) throws IOException {
		try {
		Bdd BDD = new Bdd("jdbc:mysql://localhost:3306/projet?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC", "root", "");
		BDD.connexionDataBase();
		String sql = "SELECT * FROM utilisateurs";
		PreparedStatement stat =  BDD.con.prepareStatement(sql);
		ResultSet rs =  stat.executeQuery();
					while (rs.next()) {
						data.add(new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4)));
						
					}
					BDD.con.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		UIDColumn.setCellValueFactory(new PropertyValueFactory<User , Integer>("idUser"));
		UserNameColumn.setCellValueFactory(new PropertyValueFactory<User , String>("Login"));
		PasswordColumn.setCellValueFactory(new PropertyValueFactory<User , String>("password"));
		isAdminColumn.setCellValueFactory(new PropertyValueFactory<User , String>("Statut"));
		UserTable.setItems(data);
	}
	@FXML
	private void AfficheImages(ActionEvent event) throws IOException {
        try {

        Bdd BDD = new Bdd("jdbc:mysql://localhost:3306/projet?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC", "root", "");
        BDD.connexionDataBase();
        String sql = "SELECT * FROM images";
        PreparedStatement stat =  BDD.con.prepareStatement(sql);
        ResultSet rs =  stat.executeQuery();
                    while (rs.next()) {
                        img.add(new Image(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5)));

                    }
                    BDD.con.close();
        } catch (Exception e) {
            // TODO: handle exception
        }
        ImageIDColumn.setCellValueFactory(new PropertyValueFactory<Image , Integer>("idImage"));
        ImageDateColumn.setCellValueFactory(new PropertyValueFactory<Image , String>("DateImage"));
        ImageUserIDColumn.setCellValueFactory(new PropertyValueFactory<Image , Integer>("idUtilisateur"));
        ImageTryIDColumn.setCellValueFactory(new PropertyValueFactory<Image , Integer>("idEssaie"));
        ImageUrlColumn.setCellValueFactory(new PropertyValueFactory<Image , String>("url"));
        ImageTable.setItems(img);
    }
	
	@FXML
	private void AfficheTry(ActionEvent event) throws IOException {
        try {
        Bdd BDD = new Bdd("jdbc:mysql://localhost:3306/projet?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC", "root", "");
        BDD.connexionDataBase();
        String sql = "SELECT * FROM essaie";
        PreparedStatement stat =  BDD.con.prepareStatement(sql);
        ResultSet rs =  stat.executeQuery();
                    while (rs.next()) {
                    	essaie.add(new Essaie(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getDouble(6),rs.getInt(7),rs.getInt(8)));
                    }
                    BDD.con.close();
        } catch (Exception e) {
            // TODO: handle exception
        }
        TryIDColumn.setCellValueFactory(new PropertyValueFactory<Essaie , Integer>("idEssaie"));
        TryDateColumn.setCellValueFactory(new PropertyValueFactory<Essaie , String>("DateEssaie"));
        TryDescColumn.setCellValueFactory(new PropertyValueFactory<Essaie , String>("Description"));
        ImageAmountTryColumn.setCellValueFactory(new PropertyValueFactory<Essaie , Integer>("NombresImagesEssaie"));
        CellAmountTryColumn.setCellValueFactory(new PropertyValueFactory<Essaie , Integer>("NombresCellulesEssaie"));
        MoyCellTryColumn.setCellValueFactory(new PropertyValueFactory<Essaie , Double>("MoyenneCellulesEssaie"));
        UIDTryColumn.setCellValueFactory(new PropertyValueFactory<Essaie , Integer>("idUtilisateur"));
        CampIdTryColumn.setCellValueFactory(new PropertyValueFactory<Essaie , Integer>("idCampagne"));
        TryTable.setItems(essaie);
	}
	
	@FXML
	private void AfficheCampaign(ActionEvent event) throws IOException {
        try {
        Bdd BDD = new Bdd("jdbc:mysql://localhost:3306/projet?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC", "root", "");
        BDD.connexionDataBase();
        String sql = "SELECT * FROM campagne";
        PreparedStatement stat =  BDD.con.prepareStatement(sql);
        ResultSet rs =  stat.executeQuery();
                    while (rs.next()) {
                    	campagne.add(new Campagne(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getInt(5),rs.getInt(6),rs.getInt(7)));
                    }
                    BDD.con.close();
        } catch (Exception e) {
            // TODO: handle exception
        }
        CampaignIDColumn.setCellValueFactory(new PropertyValueFactory<Campagne , Integer>("idCampagne"));
        CampaignDateColumn.setCellValueFactory(new PropertyValueFactory<Campagne , String>("dateCampagne"));
        TryAmountinCampaignColumn.setCellValueFactory(new PropertyValueFactory<Campagne , Integer>("NbrEssaie"));
        AvgCellsTryCamColumn.setCellValueFactory(new PropertyValueFactory<Campagne , Double>("moyNbrEssaie"));
        AmountCellsCamColumn.setCellValueFactory(new PropertyValueFactory<Campagne , Integer>("nbrCelCampagne"));
        AmountImgCamColumn.setCellValueFactory(new PropertyValueFactory<Campagne , Integer>("nbrImagesCamp"));
        UIDCamColumn.setCellValueFactory(new PropertyValueFactory<Campagne , Integer>("idUtilisateur"));
        CampaignTable.setItems(campagne);
	}
	@FXML
	private void AfficherAll(ActionEvent event) throws IOException {
		AfficheUsers(event);
		AfficheImages(event);
		AfficheTry(event);
		AfficheCampaign(event);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
}
