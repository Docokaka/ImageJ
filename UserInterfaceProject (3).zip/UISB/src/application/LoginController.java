package application;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import conex.Bdd;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController implements Initializable {

    @FXML
    private TextField unfield;
    @FXML
    private PasswordField pwfield;
    @FXML
    private Button loginbtn;
    
   // private String uncheck = unfield.getText();
    //private String pwcheck = pwfield.getText();
    
    @FXML
    private void loginButtonPushed(ActionEvent event) throws IOException { 

        Bdd BDD = new Bdd("jdbc:mysql://localhost:3306/projet?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC", "root", "");
        BDD.connexionDataBase();
        String uncheck = unfield.getText();
        String pwcheck = pwfield.getText();
        try {
            String sql = "SELECT pseudo, password FROM utilisateurs WHERE pseudo = '"+ uncheck +"' AND password = '"+ pwcheck +"'";
            PreparedStatement stat =  BDD.con.prepareStatement(sql);
            ResultSet rs =  stat.executeQuery();
             if (rs.next() ) {
            	 Parent manage = FXMLLoader.load(getClass().getResource("Main.fxml"));
            	 Scene scene = new Scene(manage);
            	 Stage primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            	 primaryStage.hide();
            	 primaryStage.setScene(scene);
            	 primaryStage.setTitle("Welcome");
            	 primaryStage.show();
             }
              else {
                  System.err.println("erreur");
             }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
      }    
    @FXML
    private void changeLabelValue(){
        unfield.setText("�a marche");
        System.out.println("check2");
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

		
	}
}
